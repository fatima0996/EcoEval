// content.js 
//extracts, modify and update data from web page